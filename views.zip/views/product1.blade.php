@extends('master')
<br><br><br><br><br>
@section('content')
    <!-- ======= Portfolio Details Section ======= -->
    <section id="portfolio-details" class="portfolio-details">
        <div class="container">

          <div class="row gy-4">

            <div class="col-lg-12">
              <div class="portfolio-details-slider swiper">
                  
                  <div class="card text-center">
  
  <div class="card-body">
    <h3 class="card-title"><font color="red">WOULD YOU WANT ME TO MENTOR YOU IN MAKING 1-3 MILLION NAIRA WITHIN 6 MONTHS IN YOUR AFFILIATE MARKETING BUSINESS?</font></h3>
    <p class="card-text">If your answer is Yes, I want to say a big congratulations to you in taking a big step to your financial freedom.</p>
    <p>I have successfuly coach and mentor over 1100 students in their affiliate marketing business and over 70% are getting amazing results and about 40% are already making millions why the remaining 30% are on their way in becoming a millionaire and I am 100% sure if you take action today you are definetly going to get amazing results as well.</p>
    <p>
        
        <div class="embed-responsive embed-responsive-16by9">
  <iframe width="70%" height="300" class="embed-responsive-item" src="https://www.youtube.com/embed/Hl0g9e6bcuY" allowfullscreen></iframe>
</div>
        <p><b>If you are getting my mentorship today which cost 65k, this is what you will get:</b></p>
        <p>Access to the 72IG program which cost 60k; where you're going to learn and master the skills such as Copywriting, Sales funnel building, Facebook/Instagram ads, Affiliate Marketing, Graphic and Web Design, Automations, Closing, Whatsapp marketing and Email Marketing </p>
    
    </p>
    <a href="#" class="systeme-show-popup-3901923">Click me</a><script id="form-script-tag-3901923" src="https://xincome.systeme.io/public/remote/page/558518043c555a7c5f02b6b33a2bda01d0c9cd6.js"></script>
   <form method="POST" action="{{route('paynow', $product->id)}}">
             @csrf
            
        <button type="submit" class="btn btn-primary">Click Here To Pay Now</button>
           </form>
           <p>You will also learn how to use this skills to make money online. And beyond that, you will also learn how to bring these skills together in other to start any online business. </p>
           
           <p>And In case you don't know, each of these skills will cost you 20k each to learn individually which is about 160k in total. And you don't even get to learn how to make money with these skills if you take that route.</p>
           
           <p>I also have additional bonus you will get once you get my Mentorship</p>
           
           <p>1.  I will show you how to use WhatsApp to sell effectively. If you are someone who doesn't have extra cash to run ads in your Affiliate marketing business, I will show you the same strategy and blueprint I used in generating over 10 million without spending one kobo on Facebook ads.</p>
           
           <p>I have over 400 students who have use this method to make their first 100k to 1 million without spending money on ads. Currently I have a student who have generated over 5 million without running ads.</p>
           <p>This bonus is worth 150k</p>
           
           <p> 2.  I'm going to mentor you for life, that means every business secret and strategy I know, I will be sharing it with you.
This bonus is worth 200k</p>

<p>3.  I will add you to a crypto group I created on telegram where I will educate you on how crypto works and how to start.
You will also get free signals from me that will make you good money. I will also show you how to do technical and fundamental analysis so you can look for a good signal to trade on your own. (You can't see such offer anywhere). That means you are going to learn crypto and affiliate marketing from me.</p>
<p>This bonus is worth 300k</p>

<p><form method="POST" action="{{route('paynow', $product->id)}}">
             @csrf
            
        <button type="submit" class="btn btn-primary">Click Here To Pay Now</button>
           </form></p>

<p> 4. I will add you to my 3 million in 6 Months mentorship group where you will join the challenge to hit 3 million in 6 Months using my unique strategy and Guide  
This bonus is worth 50k</p>

<p>5.  I will give you done for you templates for the hottest product on expertnaire. Your work is just to copy and paste and get results. 
This bonus is worth 20k  </p>

<p>6. We are going to be using expertnaire as our product marketplace. Registration on expertnaire is 10,000 naira for a year. When you get my mentorship, you will get a free account for one year. Check It Here to see
This bonus offer is worth 10k</p>

<p>7.  You will gain access to the same success hack I used in buying my benz and also won a car worth 3 million from Toyin Omotoso. This same success hack, my students have used it to generate over 20 million from their Affiliate Marketing business. I even received a testimony of my student who used it to fly her family abroad and got a Job as a nurse.

This bonus offer is worth 500k</p>

<p>Now you see the value of what you will get from me is priceless. You can't find this type of value for 65k anywhere in the world. You seeing this today is a blessing.</p>

<p>Total worth of bonus you are getting is 1.2 million naira.</p>

<p>It's crazy right? </p>

<p>You are getting this whole bonus worth 1.2 million naira for just 65k today if you decide to get my mentorship</p>

<p>This offer is only available for just 30 people and after that, getting my mentorship will cost you 130k.</p>

<p> <form method="POST" action="{{route('paynow', $product->id)}}">
             @csrf
            
        <button type="submit" class="btn btn-primary">Click Here To Pay Now</button>
           </form></p>
  </div>
</div>
          
                
            </div>



           
             
              
            </div>

          </div>

        </div>
      </section><!-- End Portfolio Details Section -->
@endsection
